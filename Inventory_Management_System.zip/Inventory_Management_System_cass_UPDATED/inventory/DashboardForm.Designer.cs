namespace inventory
{
    partial class DashboardForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblSub = new System.Windows.Forms.Label();
            this.pnlTotal = new System.Windows.Forms.Panel();
            this.lblTotalTitle = new System.Windows.Forms.Label();
            this.lblTotalValue = new System.Windows.Forms.Label();
            this.pnlInStock = new System.Windows.Forms.Panel();
            this.lblInStockTitle = new System.Windows.Forms.Label();
            this.lblInStockValue = new System.Windows.Forms.Label();
            this.pnlLow = new System.Windows.Forms.Panel();
            this.lblLowTitle = new System.Windows.Forms.Label();
            this.lblLowValue = new System.Windows.Forms.Label();
            this.pnlOut = new System.Windows.Forms.Panel();
            this.lblOutTitle = new System.Windows.Forms.Label();
            this.lblOutValue = new System.Windows.Forms.Label();
            this.pnlForm = new System.Windows.Forms.Panel();
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblDesc = new System.Windows.Forms.Label();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.lblCat = new System.Windows.Forms.Label();
            this.cboCategory = new System.Windows.Forms.ComboBox();
            this.lblQty = new System.Windows.Forms.Label();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.lblPrice = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.lblReorder = new System.Windows.Forms.Label();
            this.txtReorder = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.pnlList = new System.Windows.Forms.Panel();
            this.lblList = new System.Windows.Forms.Label();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.lblSearch = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.dgvProducts = new System.Windows.Forms.DataGridView();
            this.colId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCategory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colQty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colReorder = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).BeginInit();
            this.SuspendLayout();
            //
            // lblWelcome
            //
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblWelcome.ForeColor = System.Drawing.Color.White;
            this.lblWelcome.Location = new System.Drawing.Point(24, 14);
            this.lblWelcome.Text = "Welcome!";
            this.lblWelcome.BackColor = System.Drawing.Color.Transparent;
            //
            // btnLogout
            //
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(0, 0, 0);
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnLogout.FlatAppearance.BorderSize = 1;
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnLogout.ForeColor = System.Drawing.Color.White;
            this.btnLogout.Location = new System.Drawing.Point(290, 14);
            this.btnLogout.Size = new System.Drawing.Size(80, 30);
            this.btnLogout.Text = "Logout";
            this.btnLogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            //
            // lblTitle
            //
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(24, 58);
            this.lblTitle.Text = "Product Management";
            //
            // lblSub
            //
            this.lblSub.AutoSize = true;
            this.lblSub.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.lblSub.ForeColor = System.Drawing.Color.FromArgb(170, 170, 170);
            this.lblSub.Location = new System.Drawing.Point(26, 88);
            this.lblSub.Text = "Manage your inventory products";
            //
            // pnlTotal
            //
            this.pnlTotal.BackColor = System.Drawing.Color.FromArgb(34, 34, 34);
            this.pnlTotal.Location = new System.Drawing.Point(24, 122);
            this.pnlTotal.Size = new System.Drawing.Size(228, 96);
            //
            // lblTotalTitle
            //
            this.lblTotalTitle.AutoSize = false;
            this.lblTotalTitle.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblTotalTitle.ForeColor = System.Drawing.Color.White;
            this.lblTotalTitle.Location = new System.Drawing.Point(0, 12);
            this.lblTotalTitle.Size = new System.Drawing.Size(228, 26);
            this.lblTotalTitle.Text = "Total Products";
            this.lblTotalTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlTotal.Controls.Add(this.lblTotalTitle);
            //
            // lblTotalValue
            //
            this.lblTotalValue.AutoSize = false;
            this.lblTotalValue.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold);
            this.lblTotalValue.ForeColor = System.Drawing.Color.White;
            this.lblTotalValue.Location = new System.Drawing.Point(0, 44);
            this.lblTotalValue.Size = new System.Drawing.Size(228, 42);
            this.lblTotalValue.Text = "0";
            this.lblTotalValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlTotal.Controls.Add(this.lblTotalValue);
            //
            // pnlInStock
            //
            this.pnlInStock.BackColor = System.Drawing.Color.FromArgb(34, 34, 34);
            this.pnlInStock.Location = new System.Drawing.Point(264, 122);
            this.pnlInStock.Size = new System.Drawing.Size(228, 96);
            //
            // lblInStockTitle
            //
            this.lblInStockTitle.AutoSize = false;
            this.lblInStockTitle.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblInStockTitle.ForeColor = System.Drawing.Color.White;
            this.lblInStockTitle.Location = new System.Drawing.Point(0, 12);
            this.lblInStockTitle.Size = new System.Drawing.Size(228, 26);
            this.lblInStockTitle.Text = "In Stock";
            this.lblInStockTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlInStock.Controls.Add(this.lblInStockTitle);
            //
            // lblInStockValue
            //
            this.lblInStockValue.AutoSize = false;
            this.lblInStockValue.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold);
            this.lblInStockValue.ForeColor = System.Drawing.Color.White;
            this.lblInStockValue.Location = new System.Drawing.Point(0, 44);
            this.lblInStockValue.Size = new System.Drawing.Size(228, 42);
            this.lblInStockValue.Text = "0";
            this.lblInStockValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlInStock.Controls.Add(this.lblInStockValue);
            //
            // pnlLow
            //
            this.pnlLow.BackColor = System.Drawing.Color.FromArgb(34, 34, 34);
            this.pnlLow.Location = new System.Drawing.Point(504, 122);
            this.pnlLow.Size = new System.Drawing.Size(228, 96);
            //
            // lblLowTitle
            //
            this.lblLowTitle.AutoSize = false;
            this.lblLowTitle.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblLowTitle.ForeColor = System.Drawing.Color.White;
            this.lblLowTitle.Location = new System.Drawing.Point(0, 12);
            this.lblLowTitle.Size = new System.Drawing.Size(228, 26);
            this.lblLowTitle.Text = "Low Stock";
            this.lblLowTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlLow.Controls.Add(this.lblLowTitle);
            //
            // lblLowValue
            //
            this.lblLowValue.AutoSize = false;
            this.lblLowValue.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold);
            this.lblLowValue.ForeColor = System.Drawing.Color.White;
            this.lblLowValue.Location = new System.Drawing.Point(0, 44);
            this.lblLowValue.Size = new System.Drawing.Size(228, 42);
            this.lblLowValue.Text = "0";
            this.lblLowValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlLow.Controls.Add(this.lblLowValue);
            //
            // pnlOut
            //
            this.pnlOut.BackColor = System.Drawing.Color.FromArgb(34, 34, 34);
            this.pnlOut.Location = new System.Drawing.Point(744, 122);
            this.pnlOut.Size = new System.Drawing.Size(228, 96);
            //
            // lblOutTitle
            //
            this.lblOutTitle.AutoSize = false;
            this.lblOutTitle.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblOutTitle.ForeColor = System.Drawing.Color.White;
            this.lblOutTitle.Location = new System.Drawing.Point(0, 12);
            this.lblOutTitle.Size = new System.Drawing.Size(228, 26);
            this.lblOutTitle.Text = "Out of Stock";
            this.lblOutTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlOut.Controls.Add(this.lblOutTitle);
            //
            // lblOutValue
            //
            this.lblOutValue.AutoSize = false;
            this.lblOutValue.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Bold);
            this.lblOutValue.ForeColor = System.Drawing.Color.White;
            this.lblOutValue.Location = new System.Drawing.Point(0, 44);
            this.lblOutValue.Size = new System.Drawing.Size(228, 42);
            this.lblOutValue.Text = "0";
            this.lblOutValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.pnlOut.Controls.Add(this.lblOutValue);
            //
            // pnlForm
            //
            this.pnlForm.BackColor = System.Drawing.Color.FromArgb(22, 22, 22);
            this.pnlForm.Location = new System.Drawing.Point(24, 232);
            this.pnlForm.Size = new System.Drawing.Size(948, 184);
            //
            // lblName
            //
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblName.ForeColor = System.Drawing.Color.White;
            this.lblName.Location = new System.Drawing.Point(20, 14);
            this.lblName.Text = "Product Name";
            this.pnlForm.Controls.Add(this.lblName);
            //
            // txtName
            //
            this.txtName.BackColor = System.Drawing.Color.FromArgb(45, 45, 45);
            this.txtName.ForeColor = System.Drawing.Color.White;
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtName.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtName.Location = new System.Drawing.Point(20, 36);
            this.txtName.Size = new System.Drawing.Size(200, 24);
            this.txtName.MaxLength = 100;
            this.pnlForm.Controls.Add(this.txtName);
            //
            // lblDesc
            //
            this.lblDesc.AutoSize = true;
            this.lblDesc.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblDesc.ForeColor = System.Drawing.Color.White;
            this.lblDesc.Location = new System.Drawing.Point(20, 72);
            this.lblDesc.Text = "Description";
            this.pnlForm.Controls.Add(this.lblDesc);
            //
            // txtDescription
            //
            this.txtDescription.BackColor = System.Drawing.Color.FromArgb(45, 45, 45);
            this.txtDescription.ForeColor = System.Drawing.Color.White;
            this.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDescription.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtDescription.Location = new System.Drawing.Point(20, 94);
            this.txtDescription.Size = new System.Drawing.Size(200, 70);
            this.txtDescription.MaxLength = 255;
            this.txtDescription.Multiline = true;
            this.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.pnlForm.Controls.Add(this.txtDescription);
            //
            // lblCat
            //
            this.lblCat.AutoSize = true;
            this.lblCat.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblCat.ForeColor = System.Drawing.Color.White;
            this.lblCat.Location = new System.Drawing.Point(250, 14);
            this.lblCat.Text = "Category";
            this.pnlForm.Controls.Add(this.lblCat);
            //
            // cboCategory
            //
            this.cboCategory.BackColor = System.Drawing.Color.FromArgb(45, 45, 45);
            this.cboCategory.ForeColor = System.Drawing.Color.White;
            this.cboCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCategory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboCategory.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.cboCategory.Location = new System.Drawing.Point(250, 36);
            this.cboCategory.Size = new System.Drawing.Size(200, 25);
            this.pnlForm.Controls.Add(this.cboCategory);
            //
            // lblQty
            //
            this.lblQty.AutoSize = true;
            this.lblQty.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblQty.ForeColor = System.Drawing.Color.White;
            this.lblQty.Location = new System.Drawing.Point(250, 72);
            this.lblQty.Text = "Quantity";
            this.pnlForm.Controls.Add(this.lblQty);
            //
            // txtQuantity
            //
            this.txtQuantity.BackColor = System.Drawing.Color.FromArgb(45, 45, 45);
            this.txtQuantity.ForeColor = System.Drawing.Color.White;
            this.txtQuantity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtQuantity.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtQuantity.Location = new System.Drawing.Point(250, 94);
            this.txtQuantity.Size = new System.Drawing.Size(200, 24);
            this.txtQuantity.MaxLength = 9;
            this.txtQuantity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DigitsOnly_KeyPress);
            this.pnlForm.Controls.Add(this.txtQuantity);
            //
            // lblPrice
            //
            this.lblPrice.AutoSize = true;
            this.lblPrice.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblPrice.ForeColor = System.Drawing.Color.White;
            this.lblPrice.Location = new System.Drawing.Point(490, 14);
            this.lblPrice.Text = "Unit Price";
            this.pnlForm.Controls.Add(this.lblPrice);
            //
            // txtPrice
            //
            this.txtPrice.BackColor = System.Drawing.Color.FromArgb(45, 45, 45);
            this.txtPrice.ForeColor = System.Drawing.Color.White;
            this.txtPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPrice.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtPrice.Location = new System.Drawing.Point(490, 36);
            this.txtPrice.Size = new System.Drawing.Size(190, 24);
            this.txtPrice.MaxLength = 12;
            this.txtPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Price_KeyPress);
            this.pnlForm.Controls.Add(this.txtPrice);
            //
            // lblReorder
            //
            this.lblReorder.AutoSize = true;
            this.lblReorder.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblReorder.ForeColor = System.Drawing.Color.White;
            this.lblReorder.Location = new System.Drawing.Point(490, 72);
            this.lblReorder.Text = "Reorder Level";
            this.pnlForm.Controls.Add(this.lblReorder);
            //
            // txtReorder
            //
            this.txtReorder.BackColor = System.Drawing.Color.FromArgb(45, 45, 45);
            this.txtReorder.ForeColor = System.Drawing.Color.White;
            this.txtReorder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtReorder.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtReorder.Location = new System.Drawing.Point(490, 94);
            this.txtReorder.Size = new System.Drawing.Size(190, 24);
            this.txtReorder.MaxLength = 9;
            this.txtReorder.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DigitsOnly_KeyPress);
            this.pnlForm.Controls.Add(this.txtReorder);
            //
            // btnAdd
            //
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnAdd.FlatAppearance.BorderSize = 1;
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnAdd.ForeColor = System.Drawing.Color.FromArgb(0, 0, 0);
            this.btnAdd.Location = new System.Drawing.Point(750, 14);
            this.btnAdd.Size = new System.Drawing.Size(150, 30);
            this.btnAdd.Text = "Add Product";
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            this.pnlForm.Controls.Add(this.btnAdd);
            //
            // btnUpdate
            //
            this.btnUpdate.BackColor = System.Drawing.Color.FromArgb(90, 90, 90);
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(120, 120, 120);
            this.btnUpdate.FlatAppearance.BorderSize = 1;
            this.btnUpdate.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnUpdate.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnUpdate.Location = new System.Drawing.Point(750, 54);
            this.btnUpdate.Size = new System.Drawing.Size(150, 30);
            this.btnUpdate.Text = "Update";
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            this.pnlForm.Controls.Add(this.btnUpdate);
            //
            // btnDelete
            //
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(139, 26, 26);
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(180, 50, 50);
            this.btnDelete.FlatAppearance.BorderSize = 1;
            this.btnDelete.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnDelete.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnDelete.Location = new System.Drawing.Point(750, 94);
            this.btnDelete.Size = new System.Drawing.Size(150, 30);
            this.btnDelete.Text = "Delete";
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            this.pnlForm.Controls.Add(this.btnDelete);
            //
            // btnClear
            //
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(0, 0, 0);
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnClear.FlatAppearance.BorderSize = 1;
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnClear.ForeColor = System.Drawing.Color.FromArgb(255, 255, 255);
            this.btnClear.Location = new System.Drawing.Point(750, 134);
            this.btnClear.Size = new System.Drawing.Size(150, 30);
            this.btnClear.Text = "Clear";
            this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            this.pnlForm.Controls.Add(this.btnClear);
            //
            // pnlList
            //
            this.pnlList.BackColor = System.Drawing.Color.FromArgb(22, 22, 22);
            this.pnlList.Location = new System.Drawing.Point(24, 430);
            this.pnlList.Size = new System.Drawing.Size(948, 262);
            //
            // lblList
            //
            this.lblList.AutoSize = true;
            this.lblList.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblList.ForeColor = System.Drawing.Color.White;
            this.lblList.Location = new System.Drawing.Point(18, 12);
            this.lblList.Text = "Product List";
            this.pnlList.Controls.Add(this.lblList);
            //
            // btnRefresh
            //
            this.btnRefresh.BackColor = System.Drawing.Color.FromArgb(0, 0, 0);
            this.btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefresh.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btnRefresh.FlatAppearance.BorderSize = 1;
            this.btnRefresh.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnRefresh.ForeColor = System.Drawing.Color.White;
            this.btnRefresh.Location = new System.Drawing.Point(150, 10);
            this.btnRefresh.Size = new System.Drawing.Size(75, 26);
            this.btnRefresh.Text = "Refresh";
            this.btnRefresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRefresh.UseVisualStyleBackColor = false;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);
            this.pnlList.Controls.Add(this.btnRefresh);
            //
            // lblSearch
            //
            this.lblSearch.AutoSize = true;
            this.lblSearch.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblSearch.ForeColor = System.Drawing.Color.White;
            this.lblSearch.Location = new System.Drawing.Point(690, 15);
            this.lblSearch.Text = "Search";
            this.pnlList.Controls.Add(this.lblSearch);
            //
            // txtSearch
            //
            this.txtSearch.BackColor = System.Drawing.Color.FromArgb(45, 45, 45);
            this.txtSearch.ForeColor = System.Drawing.Color.White;
            this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSearch.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.txtSearch.Location = new System.Drawing.Point(745, 12);
            this.txtSearch.Size = new System.Drawing.Size(185, 24);
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            this.pnlList.Controls.Add(this.txtSearch);
            //
            // dgvProducts
            //
            this.dgvProducts.AllowUserToAddRows = false;
            this.dgvProducts.AllowUserToDeleteRows = false;
            this.dgvProducts.AllowUserToResizeRows = false;
            this.dgvProducts.ReadOnly = true;
            this.dgvProducts.RowHeadersVisible = false;
            this.dgvProducts.MultiSelect = false;
            this.dgvProducts.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProducts.EnableHeadersVisualStyles = false;
            this.dgvProducts.BackgroundColor = System.Drawing.Color.FromArgb(10, 10, 10);
            this.dgvProducts.GridColor = System.Drawing.Color.FromArgb(70, 70, 70);
            this.dgvProducts.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvProducts.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgvProducts.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(60, 60, 60);
            this.dgvProducts.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgvProducts.ColumnHeadersDefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(60, 60, 60);
            this.dgvProducts.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.dgvProducts.ColumnHeadersHeight = 32;
            this.dgvProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvProducts.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(10, 10, 10);
            this.dgvProducts.DefaultCellStyle.ForeColor = System.Drawing.Color.White;
            this.dgvProducts.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(80, 80, 80);
            this.dgvProducts.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dgvProducts.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.dgvProducts.RowTemplate.Height = 24;
            this.dgvProducts.Location = new System.Drawing.Point(18, 48);
            this.dgvProducts.Size = new System.Drawing.Size(912, 200);
            this.dgvProducts.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProducts_CellClick);

            //
            // colId
            //
            this.colId.Name = "colId";
            this.colId.HeaderText = "ID";
            this.colId.Width = 10;
            this.colId.Visible = false;
            this.colId.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //
            // colName
            //
            this.colName.Name = "colName";
            this.colName.HeaderText = "Product Name";
            this.colName.Width = 120;
            this.colName.Visible = true;
            this.colName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //
            // colCategory
            //
            this.colCategory.Name = "colCategory";
            this.colCategory.HeaderText = "Category";
            this.colCategory.Width = 110;
            this.colCategory.Visible = true;
            this.colCategory.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //
            // colDescription
            //
            this.colDescription.Name = "colDescription";
            this.colDescription.HeaderText = "Description";
            this.colDescription.Width = 190;
            this.colDescription.Visible = true;
            this.colDescription.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //
            // colPrice
            //
            this.colPrice.Name = "colPrice";
            this.colPrice.HeaderText = "Unit Price";
            this.colPrice.Width = 100;
            this.colPrice.Visible = true;
            this.colPrice.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.colPrice.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            //
            // colQty
            //
            this.colQty.Name = "colQty";
            this.colQty.HeaderText = "Quantity";
            this.colQty.Width = 70;
            this.colQty.Visible = true;
            this.colQty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //
            // colReorder
            //
            this.colReorder.Name = "colReorder";
            this.colReorder.HeaderText = "Reorder Level";
            this.colReorder.Width = 80;
            this.colReorder.Visible = true;
            this.colReorder.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //
            // colDate
            //
            this.colDate.Name = "colDate";
            this.colDate.HeaderText = "Date Added";
            this.colDate.Width = 100;
            this.colDate.Visible = true;
            this.colDate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            //
            // colStatus
            //
            this.colStatus.Name = "colStatus";
            this.colStatus.HeaderText = "Status";
            this.colStatus.Width = 100;
            this.colStatus.Visible = true;
            this.colStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dgvProducts.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
                this.colId,
                this.colName,
                this.colCategory,
                this.colDescription,
                this.colPrice,
                this.colQty,
                this.colReorder,
                this.colDate,
                this.colStatus});
            this.pnlList.Controls.Add(this.dgvProducts);
            //
            // DashboardForm
            //
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(0, 0, 0);
            this.ClientSize = new System.Drawing.Size(996, 710);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblSub);
            this.Controls.Add(this.pnlTotal);
            this.Controls.Add(this.pnlInStock);
            this.Controls.Add(this.pnlLow);
            this.Controls.Add(this.pnlOut);
            this.Controls.Add(this.pnlForm);
            this.Controls.Add(this.pnlList);
            this.Name = "DashboardForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboard";
            this.Load += new System.EventHandler(this.DashboardForm_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.DashboardForm_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblSub;
        private System.Windows.Forms.Panel pnlTotal;
        private System.Windows.Forms.Label lblTotalTitle;
        private System.Windows.Forms.Label lblTotalValue;
        private System.Windows.Forms.Panel pnlInStock;
        private System.Windows.Forms.Label lblInStockTitle;
        private System.Windows.Forms.Label lblInStockValue;
        private System.Windows.Forms.Panel pnlLow;
        private System.Windows.Forms.Label lblLowTitle;
        private System.Windows.Forms.Label lblLowValue;
        private System.Windows.Forms.Panel pnlOut;
        private System.Windows.Forms.Label lblOutTitle;
        private System.Windows.Forms.Label lblOutValue;
        private System.Windows.Forms.Panel pnlForm;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblDesc;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label lblCat;
        private System.Windows.Forms.ComboBox cboCategory;
        private System.Windows.Forms.Label lblQty;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.Label lblReorder;
        private System.Windows.Forms.TextBox txtReorder;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Panel pnlList;
        private System.Windows.Forms.Label lblList;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.DataGridView dgvProducts;
        private System.Windows.Forms.DataGridViewTextBoxColumn colId;
        private System.Windows.Forms.DataGridViewTextBoxColumn colName;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCategory;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn colQty;
        private System.Windows.Forms.DataGridViewTextBoxColumn colReorder;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colStatus;
    }
}
