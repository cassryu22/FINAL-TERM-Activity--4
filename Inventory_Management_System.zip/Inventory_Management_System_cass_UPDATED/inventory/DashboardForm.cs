using System;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace inventory
{
    public partial class DashboardForm : Form
    {
        private readonly int currentUserId;
        private readonly Form signInForm;
        private bool loggedOut = false;
        private int selectedProductId = 0;

        // Needed so the Visual Studio designer can open this form
        public DashboardForm()
        {
            InitializeComponent();
        }

        public DashboardForm(int userId, string fullName, string role, Form signIn)
        {
            InitializeComponent();
            currentUserId = userId;
            signInForm = signIn;
            lblWelcome.Text = "Welcome!";
        }

        private void DashboardForm_Load(object sender, EventArgs e)
        {
            if (DesignMode || System.ComponentModel.LicenseManager.UsageMode == System.ComponentModel.LicenseUsageMode.Designtime) return;
            cboCategory.Items.AddRange(new object[] { "Office Supplies", "Electronics", "Household", "Food & Beverage", "Clothing", "Other" });
            try
            {
                Database.EnsureProductsTable();
                LoadProducts();
                SetButtons();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not load products: " + ex.Message, "Dashboard", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ---------- helpers ----------
        private static string GetStatus(int qty, int reorder)
        {
            if (qty <= 0) return "Out of Stock";
            if (qty <= reorder) return "Low Stock";
            return "In Stock";
        }

        private void LoadProducts()
        {
            DataTable dt = Database.GetProducts(txtSearch.Text.Trim());
            dgvProducts.Rows.Clear();
            foreach (DataRow r in dt.Rows)
            {
                int qty = Convert.ToInt32(r["Quantity"]);
                int reorder = Convert.ToInt32(r["ReorderLevel"]);
                dgvProducts.Rows.Add(
                    r["ProductID"],
                    r["ProductName"],
                    r["Category"],
                    r["Description"],
                    Convert.ToDecimal(r["UnitPrice"]).ToString("N2", Inv),
                    qty,
                    reorder,
                    Convert.ToDateTime(r["DateAdded"]).ToString("yyyy-MM-dd"),
                    GetStatus(qty, reorder));
            }
            ColorStatusCells();
            UpdateCards();
        }

        private void ColorStatusCells()
        {
            foreach (DataGridViewRow row in dgvProducts.Rows)
            {
                DataGridViewCell c = row.Cells["colStatus"];
                string s = Convert.ToString(c.Value);
                if (s == "Out of Stock") { c.Style.BackColor = Color.FromArgb(120, 30, 30); }
                else if (s == "Low Stock") { c.Style.BackColor = Color.FromArgb(140, 100, 20); }
                else { c.Style.BackColor = Color.FromArgb(30, 100, 50); }
                c.Style.ForeColor = Color.White;
                c.Style.SelectionBackColor = c.Style.BackColor;
                c.Style.SelectionForeColor = Color.White;
            }
        }

        // Cards always count ALL products (not only the searched ones)
        private void UpdateCards()
        {
            int total = 0, inStock = 0, low = 0, outS = 0;
            foreach (DataRow r in Database.GetProducts("").Rows)
            {
                total++;
                string s = GetStatus(Convert.ToInt32(r["Quantity"]), Convert.ToInt32(r["ReorderLevel"]));
                if (s == "Out of Stock") outS++;
                else if (s == "Low Stock") low++;
                else inStock++;
            }
            lblTotalValue.Text = total.ToString();
            lblInStockValue.Text = inStock.ToString();
            lblLowValue.Text = low.ToString();
            lblOutValue.Text = outS.ToString();
        }

        private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

        private void Warn(string message, Control focus)
        {
            MessageBox.Show(message, "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            if (focus != null) focus.Focus();
        }

        // Is there another product (different ID) with the same name?
        private bool NameExists(string name, int exceptId)
        {
            foreach (DataRow r in Database.GetProducts("").Rows)
            {
                if (Convert.ToInt32(r["ProductID"]) == exceptId) continue;
                if (string.Equals(Convert.ToString(r["ProductName"]).Trim(), name, StringComparison.OrdinalIgnoreCase))
                    return true;
            }
            return false;
        }

        private bool ReadForm(out string name, out string category, out string desc, out decimal price, out int qty, out int reorder)
        {
            name = txtName.Text.Trim();
            category = cboCategory.Text.Trim();
            desc = txtDescription.Text.Trim();
            price = 0; qty = 0; reorder = 0;

            if (name.Length == 0) { Warn("Product Name is required.", txtName); return false; }
            if (name.Length > 100) { Warn("Product Name must be 100 characters or less.", txtName); return false; }
            if (category.Length == 0 || cboCategory.SelectedIndex < 0) { Warn("Please choose a Category.", cboCategory); return false; }
            if (desc.Length > 255) { Warn("Description must be 255 characters or less.", txtDescription); return false; }

            string priceText = txtPrice.Text.Trim().Replace(",", "");
            if (priceText.Length == 0) { Warn("Unit Price is required.", txtPrice); return false; }
            if (!decimal.TryParse(priceText, NumberStyles.AllowDecimalPoint, Inv, out price))
            { Warn("Unit Price must be a valid number (example: 150.50).", txtPrice); return false; }
            if (price <= 0) { Warn("Unit Price must be greater than 0.", txtPrice); return false; }
            if (price > 999999999m) { Warn("Unit Price is too large.", txtPrice); return false; }
            price = Math.Round(price, 2);

            string qtyText = txtQuantity.Text.Trim();
            if (qtyText.Length == 0) { Warn("Quantity is required (enter 0 if none).", txtQuantity); return false; }
            if (!int.TryParse(qtyText, NumberStyles.None, Inv, out qty))
            { Warn("Quantity must be a whole number (0 or more).", txtQuantity); return false; }

            string reText = txtReorder.Text.Trim();
            if (reText.Length == 0) { Warn("Reorder Level is required (enter 0 if none).", txtReorder); return false; }
            if (!int.TryParse(reText, NumberStyles.None, Inv, out reorder))
            { Warn("Reorder Level must be a whole number (0 or more).", txtReorder); return false; }

            return true;
        }

        private bool HasAnyInput()
        {
            return txtName.Text.Trim().Length > 0 || txtDescription.Text.Trim().Length > 0 ||
                   txtPrice.Text.Trim().Length > 0 || txtQuantity.Text.Trim().Length > 0 ||
                   txtReorder.Text.Trim().Length > 0 || cboCategory.SelectedIndex >= 0;
        }

        private void SetButtons()
        {
            bool selected = selectedProductId != 0;
            btnUpdate.Enabled = selected;
            btnDelete.Enabled = selected;
            btnAdd.Enabled = !selected;   // adding while a product is selected would create a duplicate
        }

        private void ClearForm()
        {
            selectedProductId = 0;
            txtName.Clear(); txtDescription.Clear(); txtPrice.Clear();
            txtQuantity.Clear(); txtReorder.Clear();
            cboCategory.SelectedIndex = -1;
            dgvProducts.ClearSelection();
            SetButtons();
            txtName.Focus();
        }

        // ---------- number-only typing ----------
        private void DigitsOnly_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar)) e.Handled = true;
        }

        private void Price_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsControl(e.KeyChar) || char.IsDigit(e.KeyChar)) return;
            TextBox t = (TextBox)sender;
            if (e.KeyChar == '.' && t.Text.IndexOf('.') < 0) return;
            e.Handled = true;
        }

        // ---------- buttons ----------
        private void btnAdd_Click(object sender, EventArgs e)
        {
            string name, cat, desc; decimal price; int qty, reorder;
            if (!ReadForm(out name, out cat, out desc, out price, out qty, out reorder)) return;
            try
            {
                if (NameExists(name, 0)) { Warn("A product named \"" + name + "\" already exists.", txtName); return; }
                Database.InsertProduct(name, cat, desc, price, qty, reorder);
                Database.LogActivity(currentUserId, "Added product: " + name);
                txtSearch.Clear();
                LoadProducts(); ClearForm();
                MessageBox.Show("Product added.", "Add Product", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message, "Add Product", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedProductId == 0)
            {
                MessageBox.Show("Select a product from the list first.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string name, cat, desc; decimal price; int qty, reorder;
            if (!ReadForm(out name, out cat, out desc, out price, out qty, out reorder)) return;
            try
            {
                if (NameExists(name, selectedProductId)) { Warn("Another product named \"" + name + "\" already exists.", txtName); return; }
                Database.UpdateProduct(selectedProductId, name, cat, desc, price, qty, reorder);
                Database.LogActivity(currentUserId, "Updated product: " + name);
                LoadProducts(); ClearForm();
                MessageBox.Show("Product updated.", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message, "Update", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedProductId == 0)
            {
                MessageBox.Show("Select a product from the list first.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string name = txtName.Text.Trim();
            if (MessageBox.Show("Delete \"" + name + "\"? This cannot be undone.", "Delete",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            try
            {
                Database.DeleteProduct(selectedProductId);
                Database.LogActivity(currentUserId, "Deleted product: " + name);
                LoadProducts(); ClearForm();
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message, "Delete", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            if (selectedProductId == 0 && !HasAnyInput())
            {
                MessageBox.Show("The form is already empty.", "Clear", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            ClearForm();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            LoadProducts();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            try { LoadProducts(); } catch { }
        }

        private void dgvProducts_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            DataGridViewRow r = dgvProducts.Rows[e.RowIndex];
            selectedProductId = Convert.ToInt32(r.Cells["colId"].Value);
            txtName.Text = Convert.ToString(r.Cells["colName"].Value);
            cboCategory.Text = Convert.ToString(r.Cells["colCategory"].Value);
            txtDescription.Text = Convert.ToString(r.Cells["colDescription"].Value);
            txtPrice.Text = Convert.ToString(r.Cells["colPrice"].Value).Replace(",", "");
            SetButtons();
            txtQuantity.Text = Convert.ToString(r.Cells["colQty"].Value);
            txtReorder.Text = Convert.ToString(r.Cells["colReorder"].Value);
        }

        // Logout: back to the Sign In page
        private void btnLogout_Click(object sender, EventArgs e)
        {
            Database.LogActivity(currentUserId, "Signed out");
            loggedOut = true;
            if (signInForm != null) signInForm.Show();
            this.Close();
        }

        private void DashboardForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Closing with the X button ends the whole application
            if (!loggedOut) Application.Exit();
        }
    }
}
