using System;
using System.Data.OleDb;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace inventory
{
    public static class Database
    {
        // sampledb.accdb sits in the project folder (two levels above bin\Debug), same as in the video
        public static readonly string DBpATH = Path.GetFullPath(
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\sampledb.accdb"));

        private static readonly string connectionString =
            @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + DBpATH + ";Persist Security Info=False;";

        public static OleDbConnection GetConnection()
        {
            return new OleDbConnection(connectionString);
        }

        // ---- kept from your original project so Sign In / Register / Dashboard keep working ----

        public static string HashPassword(string password)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder sb = new StringBuilder();
                foreach (byte b in bytes) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        public static void LogActivity(int userId, string action)
        {
            try
            {
                using (OleDbConnection con = GetConnection())
                using (OleDbCommand cmd = new OleDbCommand(
                    "INSERT INTO ActivityLogs (UserID, ActionText, LogDate) VALUES (?, ?, ?)", con))
                {
                    cmd.Parameters.Add("?", OleDbType.Integer).Value = userId;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = action;
                    cmd.Parameters.Add("?", OleDbType.Date).Value = DateTime.Now;
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch { /* logging should never crash the app */ }
        }
    
        // ---------------- PRODUCTS ----------------

        // Creates the Products table the first time the dashboard opens (with the 5 sample items)
        public static void EnsureProductsTable()
        {
            bool exists = false;
            using (OleDbConnection con = GetConnection())
            {
                con.Open();
                System.Data.DataTable t = con.GetSchema("Tables");
                foreach (System.Data.DataRow r in t.Rows)
                {
                    if (string.Equals(r["TABLE_NAME"].ToString(), "Products", StringComparison.OrdinalIgnoreCase)
                        && r["TABLE_TYPE"].ToString() == "TABLE") { exists = true; break; }
                }
                if (!exists)
                {
                    using (OleDbCommand cmd = new OleDbCommand(
                        "CREATE TABLE Products (ProductID COUNTER PRIMARY KEY, ProductName TEXT(100), Category TEXT(50), " +
                        "Description TEXT(255), UnitPrice CURRENCY, Quantity LONG, ReorderLevel LONG, DateAdded DATETIME)", con))
                        cmd.ExecuteNonQuery();
                }
            }
            if (exists) return;

            InsertProduct("Ballpen", "Office Supplies", "0.5mm Black pen.", 15m, 0, 1);
            InsertProduct("Iphone 18", "Electronics", "Best for everything", 100000m, 10, 0);
            InsertProduct("Mop", "Household", "Good for cleaning the floor", 218m, 50, 2);
            InsertProduct("Orange", "Food & Beverage", "Sweeter than the sun", 30m, 1, 100);
            InsertProduct("T-shirt", "Clothing", "Cotton plain shirt", 200m, 100, 4);
        }

        public static System.Data.DataTable GetProducts(string search)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            using (OleDbConnection con = GetConnection())
            using (OleDbCommand cmd = new OleDbCommand(
                "SELECT ProductID, ProductName, Category, Description, UnitPrice, Quantity, ReorderLevel, DateAdded " +
                "FROM Products WHERE ProductName LIKE ? OR Category LIKE ? OR Description LIKE ? ORDER BY ProductID", con))
            {
                string like = "%" + (search ?? "") + "%";
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = like;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = like;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = like;
                new OleDbDataAdapter(cmd).Fill(dt);
            }
            return dt;
        }

        public static void InsertProduct(string name, string category, string description, decimal price, int qty, int reorder)
        {
            using (OleDbConnection con = GetConnection())
            using (OleDbCommand cmd = new OleDbCommand(
                "INSERT INTO Products (ProductName, Category, Description, UnitPrice, Quantity, ReorderLevel, DateAdded) VALUES (?, ?, ?, ?, ?, ?, ?)", con))
            {
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = name;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = category;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = description ?? "";
                cmd.Parameters.Add("?", OleDbType.Currency).Value = price;
                cmd.Parameters.Add("?", OleDbType.Integer).Value = qty;
                cmd.Parameters.Add("?", OleDbType.Integer).Value = reorder;
                cmd.Parameters.Add("?", OleDbType.Date).Value = DateTime.Now;
                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static void UpdateProduct(int id, string name, string category, string description, decimal price, int qty, int reorder)
        {
            using (OleDbConnection con = GetConnection())
            using (OleDbCommand cmd = new OleDbCommand(
                "UPDATE Products SET ProductName=?, Category=?, Description=?, UnitPrice=?, Quantity=?, ReorderLevel=? WHERE ProductID=?", con))
            {
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = name;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = category;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = description ?? "";
                cmd.Parameters.Add("?", OleDbType.Currency).Value = price;
                cmd.Parameters.Add("?", OleDbType.Integer).Value = qty;
                cmd.Parameters.Add("?", OleDbType.Integer).Value = reorder;
                cmd.Parameters.Add("?", OleDbType.Integer).Value = id;
                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static void DeleteProduct(int id)
        {
            using (OleDbConnection con = GetConnection())
            using (OleDbCommand cmd = new OleDbCommand("DELETE FROM Products WHERE ProductID=?", con))
            {
                cmd.Parameters.Add("?", OleDbType.Integer).Value = id;
                con.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
